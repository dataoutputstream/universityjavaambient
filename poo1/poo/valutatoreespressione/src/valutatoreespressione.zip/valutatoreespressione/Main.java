package valutatoreespressione;

public class Main {
	public static void main(String...Args) {
		//JButton piu=new JButton("+");
		//System.out.println(piu.getText());
		
		Grafica g=new Grafica();
		g.setVisible(true);
	}
	

}
